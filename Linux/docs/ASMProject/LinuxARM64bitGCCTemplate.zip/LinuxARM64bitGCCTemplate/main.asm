/* Since we are using main, this program will use the */
/* C runtime instead of pure assembler */


.section .data        /* Our read/write data section */
value1:		.word	123
welcome:	.asciz	"\nWelcome to my ARM 64-bit program\n"
goodbye:	.asciz	"\nProgram ending, have a nice day\n"
intPrint:	.asciz	"An Integer: %d \n"

.section .bss

.section .text			//Beginning of our code segment
.global main			//Our entry point
.extern printf
main:
    ldr x0, =welcome	//The address of the welcome string
    bl printf			//Execute printf

    ldr x0, =intPrint	//Format string
    ldr x2, =value1		//Address of our number
    ldr x1, [x2]
    bl printf			//Execute printf

    ldr x0, =goodbye	//Address of our string
    bl printf

/* syscall exit(int status) */
    mov x0, #0 
    mov w8, #93 
    svc #0
	
