/* Since we are using main, this program will use the */
/* C runtime instead of pure assembler */

.section .data        /* Our read/write data section */
value1:		.word	123
welcome:	.asciz	"\nWelcome to my ARM 32-bit program\n"
goodbye:	.asciz	"\nProgram ending, have a nice day\n"
intPrint:	.asciz	"An Integer: %d \n"

.section .bss

.section .text			@Beginning of our code segment
.global main	@Our entry point
.extern printf
main:
    ldr r0, =welcome		@The address of the welcome string
    bl printf			@Execute printf

    ldr r0, =intPrint	@Format string
    ldr r2, =value1		@Address of our number
    ldr r1, [r2]
    bl printf			@Execute printf

    ldr r0, =goodbye	@Address of our string
    bl printf

    mov	R7, #1   /* 1 tells the operating system to end the program */
    svc 0        /* svc 0 is the system call to the operating system */

    /*bx lr       Alternative return Return from main and end program */
	
